﻿using System;
using System.Collections.Generic;

namespace FianlGUI.Models
{
    public partial class Logins
    {
        public string Username { get; set; }
        public string Passwords { get; set; }
        public string Accesslevel { get; set; }
    }
}
