﻿using System;
using System.Collections.Generic;

namespace FianlGUI.Models
{
    public partial class Wrote
    {
        public string BookCode { get; set; }
        public decimal AuthorNum { get; set; }
        public decimal? Sequence { get; set; }
    }
}
