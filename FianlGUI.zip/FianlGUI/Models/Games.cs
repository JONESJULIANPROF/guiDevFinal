﻿using System;
using System.Collections.Generic;

namespace FianlGUI.Models
{
    public partial class Games
    {
        public int Id { get; set; }
        public string Game { get; set; }
        public string Platform { get; set; }
        public string Cheattitle { get; set; }
        public string Cheatcode { get; set; }
    }
}
