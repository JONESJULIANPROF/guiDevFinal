﻿using System;
using System.Collections.Generic;

namespace FianlGUI.Models
{
    public partial class Authorview1
    {
        public decimal Authornum { get; set; }
        public string Authorlast { get; set; }
        public string Authorfirst { get; set; }
        public string Title { get; set; }
    }
}
