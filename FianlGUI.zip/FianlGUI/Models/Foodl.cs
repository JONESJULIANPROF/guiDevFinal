﻿using System;
using System.Collections.Generic;

namespace FianlGUI.Models
{
    public partial class Foodl
    {
        public string Food { get; set; }
        public int Calories { get; set; }
        public int Protein { get; set; }
        public int Carb { get; set; }
        public int Fat { get; set; }
    }
}
