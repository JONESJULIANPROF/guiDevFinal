﻿using System;
using System.Collections.Generic;

namespace FianlGUI.Models
{
    public partial class Bookview1
    {
        public string Title { get; set; }
        public string Quality { get; set; }
        public decimal? Price { get; set; }
        public decimal? Tax { get; set; }
    }
}
