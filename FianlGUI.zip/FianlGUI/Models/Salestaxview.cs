﻿using System;
using System.Collections.Generic;

namespace FianlGUI.Models
{
    public partial class Salestaxview
    {
        public string Title { get; set; }
        public decimal? Price { get; set; }
        public decimal? SalesTax { get; set; }
    }
}
